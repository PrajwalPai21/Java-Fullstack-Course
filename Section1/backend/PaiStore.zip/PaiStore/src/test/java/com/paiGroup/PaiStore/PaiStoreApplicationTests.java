package com.paiGroup.PaiStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaiStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
